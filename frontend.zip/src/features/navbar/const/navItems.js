export const NAV_ITEMS = [
  { label: 'Mapa', active: true },
  { label: 'Selección', active: false },
  { label: 'Edición', active: false },
  { label: 'Proyecto', active: false },
];