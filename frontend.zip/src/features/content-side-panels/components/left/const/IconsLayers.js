import showList from '@/shared/assets/svg/leftLayerPanel/mostrar_lista.svg'
import showTag from '@/shared/assets/svg/leftLayerPanel/Mostrar_etiqueta.svg'


export {
    showList,
    showTag,
}